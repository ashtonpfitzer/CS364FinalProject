//file: dashboard.js
// used by dashboard.html to fetch users from the database
// and udpate HTML table with user data

async function fetchUsers() {
    const response = await fetch("/api/users", { credentials: "include" });
    const users = await response.json();

    if (response.ok) {
        // get HTML table (going to modify this)
        const userTable = document.getElementById("userList");
        userTable.innerHTML = ""; // clear the previous content of the table

        // for each user in result, create table row and append to table in DOM
        users.forEach(user => {  
            const row = document.createElement("tr");
            row.innerHTML = `<td>${user.username}</td><td>${user.email}</td><td>${user.role}</td><td>${user.numreviewed}</td><td><button class="actionElevate" data-id="${user.email}">Elevate</button><button class="actionRemove" data-id="${user.email}">Remove Admin</button></td>`;
            row.querySelector('.actionElevate').addEventListener('click', () => elevateUser(user.email, 'Elevate'));
            row.querySelector('.actionRemove').addEventListener('click', () => elevateUser(user.email, 'RemoveAdmin'));
            userTable.appendChild(row);
        });

    } else {
        window.location.href = "/frontpage.html";
    }


}

async function elevateUser(id, action){
    const response = await fetch(`/api/users/${id}/role`, { 
        method:"POST", 
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action })
    });
    if(response.ok){
        fetchUsers();
    }
}

async function limitFinder(){
    newint = parseInt(document.getElementById("limit").value, 10);
    if(newint < 40 && newint > 0){
        return newint
    }
    else{
        return 10;
    }
}
const limit = limitFinder();

async function fetchRebuttals(limit){
    const responseReb = await fetch(`/api/rebuttals?limit=${limit}`, { credentials: "include" });
    const rebuttals = await responseReb.json();
    if(responseReb.ok){
        const rebuttalsTable = document.getElementById("rebuttalsList");
        rebuttalsTable.innerHTML = ""; 
        rebuttals.forEach(rebuttal => {  
            const rowReb = document.createElement("tr");
            rowReb.innerHTML = `<td>${rebuttal.rebuttalnum}</td><td>${rebuttal.roomnum}</td><td>${rebuttal.squadron}</td><td>${rebuttal.info}</td><td>${rebuttal.status}</td><td><button class="actionApprove" data-id="${rebuttal.rebuttalnum}">Approve</button><button class="actionDeny" data-id="${rebuttal.rebuttalnum}">Deny</button></td>`;
            rebuttalsTable.appendChild(rowReb);

            rowReb.querySelector('.actionApprove').addEventListener('click', () => reviewRebuttal(rebuttal.rebuttalnum, 'Approved'));
            rowReb.querySelector('.actionDeny').addEventListener('click', () => reviewRebuttal(rebuttal.rebuttalnum, 'Denied'));
        });
    }
}

async function fetchReviewed(){
    const responseReb = await fetch("/api/reviewed", { credentials: "include" });
    const reviewed = await responseReb.json();
    if(responseReb.ok){
        const rebuttalsTable = document.getElementById("reviewedList");
        rebuttalsTable.innerHTML = ""; 
        reviewed.forEach(rebuttal => {  
            const rowReb = document.createElement("tr");
            rowReb.innerHTML = `<td>${rebuttal.rebuttalnum}</td><td>${rebuttal.roomnum}</td><td>${rebuttal.status}</td><td>${rebuttal.reviewedby}</td>`;
            rebuttalsTable.appendChild(rowReb);
        });
    }
}

async function fetchRooms(){
    const responseReb = await fetch("/api/rooms", { credentials: "include" });
    const reviewed = await responseReb.json();
    if(responseReb.ok){
        const rebuttalsTable = document.getElementById("roomList");
        rebuttalsTable.innerHTML = ""; 
        reviewed.forEach(rebuttal => {  
            const rowReb = document.createElement("tr");
            rowReb.innerHTML = `<td>${rebuttal.roomnum}</td><td>${rebuttal.occupant1}</td><td>${rebuttal.occupant2}</td><td>${rebuttal.occupant3}</td>`;
            rebuttalsTable.appendChild(rowReb);
        });
    }
}

async function truncateRebuttals(){
    const responseReb = await fetch("/api/rebuttals", { method:"DELETE", credentials: "include" });
    if(responseReb.ok){
        fetchRebuttals();
        fetchReviewed();
        fetchRooms();
    }
}

async function populateRebuttals(){
    
    const responseReb = await fetch("/api/rebuttals", { 
        method:"POST", 
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
        roomnum: document.getElementById("rebRoom").value,
        squadron: parseInt(document.getElementById("rebSq").value, 10),
        info: document.getElementById("rebInfo").value,
        status: document.getElementById("rebStatus").value}) });
    if(responseReb.ok){
        fetchRebuttals();
    }
}

async function reviewRebuttal(id, action){
    const responseReb = await fetch(`/api/rebuttals/${id}/review`, { 
        method:"POST", 
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action })
    });
    if(responseReb.ok){
        const beforeParse = document.getElementById("limit").value;
        const limit = parseInt(beforeParse, 10) || 10;
        fetchRebuttals(limit);
        fetchUsers();
        fetchReviewed();
    }
}

document.getElementById("display").addEventListener("click", () => {
    const beforeParse = document.getElementById("limit").value;
    const limit = parseInt(beforeParse, 10) || 10;
    fetchRebuttals(limit);
  });  
document.getElementById("truncate").addEventListener("click", truncateRebuttals);
//document.getElementById("insertRow").addEventListener("click", populateRebuttals);
fetchUsers();
fetchRebuttals(parseInt(document.getElementById("limit").value, 10) || 10);
fetchReviewed();
fetchRooms();

