-- taking the easy way: use the default database: postgres
CREATE TABLE IF NOT EXISTS users (
    "StudentID" SERIAL PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    squadron INTEGER NOT NULL,
    hash CHAR(128) NOT NULL,
    salt CHAR(32) NOT NULL,
    numreviewed INTEGER DEFAULT 0,
    role VARCHAR(10) CHECK (role IN ('user', 'admin')) NOT NULL DEFAULT 'user'
);

select * from users;

--CREATE TABLE IF NOT EXISTS "STAFF"(
--    "StudentID" INTEGER UNIQUE,
--    "Role" VARCHAR(25) NOT NULL,
--    "NumReviewed" INTEGER DEFAULT 0,
--    CONSTRAINT "staff_pkey" PRIMARY KEY ("StudentID"),
--    CONSTRAINT "staff_studentid_fkey" FOREIGN KEY ("StudentID") REFERENCES users("StudentID")
--);

CREATE TABLE IF NOT EXISTS "ROOMINFO"(
    "RoomNum" VARCHAR(6),
    "Occupant1" VARCHAR(100) NOT NULL,
    "Occupant2" VARCHAR(100),
    "Occupant3" VARCHAR(100),
    CONSTRAINT "roominfo_pkey" PRIMARY KEY ("RoomNum")
);

CREATE TABLE IF NOT EXISTS "REBUTTALINFO"(
    "RebuttalNum" SERIAL,
    "RoomNum" VARCHAR(6) NOT NULL,
    "Squadron" INTEGER NOT NULL,
    "Info" VARCHAR(5000) NOT NULL,
    "Status" VARCHAR(15) NOT NULL,
    CONSTRAINT "rebuttalinfo_pkey" PRIMARY KEY ("RebuttalNum")
);

CREATE TABLE IF NOT EXISTS "REVIEWED"(
    "RebuttalNum" INTEGER,
    "RoomNum" VARCHAR(6) NOT NULL,
    "Status" VARCHAR(15) NOT NULL,
    "ReviewedBy" VARCHAR(100),
    CONSTRAINT "reviewed_pkey" PRIMARY KEY ("RebuttalNum")
);

-- username: Ashton Pfitzer
-- email: ashtonpfitzer@gmail.com
-- password: aaa
--     role: admin
INSERT INTO users (username, email, squadron, hash, salt, numreviewed, role) VALUES ('Ashton Pfitzer', 'ashtonpfitzer@gmail.com', 40, '2d2cfaf98432a4b9c8d12a9c36321675e5d588e04dca96f8211a5619d4739208f564fe959c52dc3fd389d90221cfc8c06a7b4e29818005e0daa5bdc9915b585a', '465f6c9310986b130f11a90e83dae3b7', 0, 'admin');