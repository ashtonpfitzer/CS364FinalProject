//file: frontpage.html


async function populateRebuttals(){
    
    const responseReb = await fetch("/api/rebuttals", { 
        method:"POST", 
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
        roomnum: document.getElementById("roomnumber").value,
        squadron: parseInt(document.getElementById("squadron").value, 10),
        info: document.getElementById("information").value,
        status: "Pending"}) });
    if(responseReb.ok){
        //fetchRebuttals();
    }
}

async function populateRoom(){
    
    const responseReb = await fetch("/api/room", { 
        method:"POST", 
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
        roomnum: document.getElementById("roomnumber").value,
        occupant1: document.getElementById("occupant1").value,
        occupant2: document.getElementById("occupant2").value,
        occupant3: document.getElementById("occupant3").value }) });
    if(responseReb.ok){
        //fetchRebuttals();
    }
}

document.getElementById("submit").addEventListener("click", populateRebuttals);
document.getElementById("submit").addEventListener("click", populateRoom);
//fetchUsers();

