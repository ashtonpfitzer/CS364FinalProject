//file: dashboard.js
// used by dashboard.html to fetch users from the database
// and udpate HTML table with user data

async function fetchUsers() {
    const response = await fetch("/api/users", { credentials: "include" });
    const users = await response.json();

    if (response.ok) {
        // get HTML table (going to modify this)
        const userTable = document.getElementById("userList");
        userTable.innerHTML = ""; // clear the previous content of the table

        // for each user in result, create table row and append to table in DOM
        users.forEach(user => {  
            const row = document.createElement("tr");
            row.innerHTML = `<td>${user.username}</td><td>${user.email}</td><td>${user.role}</td>`;
            userTable.appendChild(row);
        });

    } else {
        window.location.href = "/frontpage.html";
    }


}

async function limitFinder(){
    newint = parseInt(document.getElementById("limit").value, 10);
    if(newint < 40 && newint > 0){
        return newint
    }
    else{
        return 10;
    }
}
const limit = limitFinder();

async function fetchRebuttals(limit) {
    const responseReb = await fetch(`/api/rebuttals?limit=${limit}`, { credentials: "include" });
    const rebuttals = await responseReb.json();
    if(responseReb.ok){
        const rebuttalsTable = document.getElementById("rebuttalsList");
        rebuttalsTable.innerHTML = ""; 
        rebuttals.forEach(rebuttal => {  
            const rowReb = document.createElement("tr");
            rowReb.innerHTML = `<td>${rebuttal.rebuttalnum}</td><td>${rebuttal.roomnum}</td><td>${rebuttal.squadron}</td><td>${rebuttal.info}</td><td>${rebuttal.status}</td><td><button class="action">Approve</button><button class="action">Deny</button></td>`;
            rebuttalsTable.appendChild(rowReb);
        });
    }
}

async function truncateRebuttals(){
    const responseReb = await fetch("/api/rebuttals", { method:"DELETE", credentials: "include" });
    if(responseReb.ok){
        fetchRebuttals();
    }
}

async function populateRebuttals(){
    
    const responseReb = await fetch("/api/rebuttals", { 
        method:"POST", 
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
        roomnum: document.getElementById("rebRoom").value,
        squadron: parseInt(document.getElementById("rebSq").value, 10),
        info: document.getElementById("rebInfo").value,
        status: document.getElementById("rebStatus").value}) });
    if(responseReb.ok){
        fetchRebuttals();
    }
}

document.getElementById("display").addEventListener("click", () => {
    const raw = document.getElementById("limit").value;
    const limit = parseInt(raw, 10) || 10;
    fetchRebuttals(limit);
  });  
document.getElementById("truncate").addEventListener("click", truncateRebuttals);
document.getElementById("insertRow").addEventListener("click", populateRebuttals);
fetchUsers();

